<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Marketplace
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webapp\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManager;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Webkul\Marketplace\Helper\Data as MarketplaceHelper;
use Webkul\Marketplace\Helper\Notification as NotificationHelper;

/**
 * Webkul Marketplace SalesOrderSuccessObserver Observer Model.
 */
class SalesOrderSuccessObserver extends \Webkul\Marketplace\Observer\SalesOrderSuccessObserver
{
    
    /**
     * Sales Order Place After event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getOrderIds();
        foreach ($orderIds as $lastOrderId) {
            $sellerOrder = $this->_objectManager->create(
                'Webkul\Marketplace\Model\Orders'
            )
            ->getCollection()
            ->addFieldToFilter('order_id', $lastOrderId);

             
            /*Add logic to split orders*/
            $this->splitOrder($lastOrderId, $sellerOrder);

            if (!count($sellerOrder)) {
                /** @var $orderInstance Order */
                $order = $this->_orderRepository->get($lastOrderId);
                $this->orderPlacedOperations($order, $lastOrderId);
            }
        }
    }


    /**
     * split orders based on sellers.
     *
     * @param Integer $orderId
     * @param \Webkul\Marketplace\Model\Orders $sellerOrders
    */
    public function splitOrder($orderId, $sellerOrders)
    {
        $createOrderHelper = $this->_objectManager->create(
                'Webapp\Marketplace\Helper\Data'
            );
        //if(count($sellerOrders->getData()) > 1 && $orderId){
            $sellerOrders = $sellerOrders->getData();
            $test = array();
            foreach ($sellerOrders as $key => $orderdata) {
                $formatedData = $this->formateOrderData($orderdata);
                $test[] = $formatedData;
                $result = $createOrderHelper->createOrder($formatedData);
                if($result['order_id']){
                    $sellerOrder = $this->_objectManager->create('Webkul\Marketplace\Model\Orders')->load($orderdata['entity_id']);
                    $mainOrderId = $sellerOrder->getOrderId();
                    $sellerOrder->setParentOrder($mainOrderId);
                    $sellerOrder->setOrderId(0);
                    $sellerOrder->save();

                    /*Set main order id as parent id*/
                    $sellerSplitOrder = $this->_objectManager->create('Webkul\Marketplace\Model\Orders')
                        ->getCollection()
                        ->addFieldToFilter('order_id', $result['order_id']);
                    if(count($sellerSplitOrder)){
                        foreach ($sellerSplitOrder as $splitOrder) {
                            $splitOrder->setParentOrder($mainOrderId);
                            $splitOrder->save();
                        }
                    }
                }
            }
            //echo "<pre>";print_r($formatedData);die;
        //}
    }


    /**
     * Formate seller order data.
     *
     * @param \Webkul\Marketplace\Model\Orders $sellerOrders
    */

    public function formateOrderData($sellerOrder)
    {
        $order =  $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($sellerOrder['order_id']);
        
        $paymentCode = '';
        if ($order->getPayment()) {
            $paymentCode = $order->getPayment()->getMethod();
        }
        $shippingMethod = '';
        if ($order->getShippingMethod()) {
            $shippingMethod = $order->getShippingMethod();
        }
        $currencyCode = $order->getOrderCurrencyCode();
        $email = $order->getCustomerEmail();
        $firstname = $order->getBillingAddress()->getFirstname();
        $lastname= $order->getBillingAddress()->getLastname();
         
        //$billingAddress = $order->getBillingAddress()->getData();
        $street = $order->getBillingAddress()->getStreet();
        $city = $order->getBillingAddress()->getCity(); 
        $country_id = $order->getBillingAddress()->getCountryId();
        $region_id = $order->getBillingAddress()->getRegionId();
        $region = $order->getBillingAddress()->getRegion();
        $postcode = $order->getBillingAddress()->getPostcode(); 
        $telephone = $order->getBillingAddress()->getTelephone(); 
        $fax = $order->getBillingAddress()->getFax();
        /*if ($order->getShippingAddress()) {
            $shippingId = $order->getShippingAddress()->getId();
            $address = $this->_objectManager->create(
                'Magento\Sales\Model\Order\Address'
            )->load($shippingId);
            $street = @$address['street'];
            $city = @$address['city'];
            $country_id = @$address['country_id'];
            $region = @$address['region'];
            $postcode = @$address['postcode'];
            $telephone = @$address['telephone'];
            $fax = @$address['fax'];
        }*/
        $items = array();
        $productsIds = explode(',', $sellerOrder['product_ids']);
        foreach ($order->getAllItems() as $item) {
            $itemData = $item->getData();
            if(in_array($itemData['product_id'], $productsIds)){
                $items[] = $item->getData();
            }
        }

        
        if(!empty($items)){
            $Orderdata=[
                'currency_id'  => $currencyCode,
                'email'        => $email, //buyer email id
                'shippingMethod' => $shippingMethod,
                'paymentMethod'  => $paymentCode,
                'shipping_address' =>[
                    'firstname'    => $firstname,
                    'lastname'     => $lastname,
                    'street' => $street,
                    'city' => $city,
                    'country_id' => $country_id,
                    'region_id' => $region_id,
                    'region' => $region,
                    'postcode' => $postcode,
                    'telephone' => $telephone,
                    'fax' => $fax,
                    'save_in_address_book' => 1
                    ],
               'items'=> $items
            ];
            return $Orderdata;
        }
    }

}
