<?php
namespace Potato\ImageOptimization\Logger;

class Logger extends \Monolog\Logger
{
}