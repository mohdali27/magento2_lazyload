<?php
namespace Potato\Compressor\Model\Optimisation\Processor\Finder;

interface ImageInterface extends FinderInterface
{
}