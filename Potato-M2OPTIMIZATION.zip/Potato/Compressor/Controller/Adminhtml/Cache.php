<?php

namespace Potato\Compressor\Controller\Adminhtml;

use Magento\Backend\App\Action;

/**
 * Class Index
 */
abstract class Cache extends Action
{
    const ADMIN_RESOURCE = 'Potato_Compressor::po_compressor';
}
