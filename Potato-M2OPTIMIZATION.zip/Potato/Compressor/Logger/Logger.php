<?php
namespace Potato\Compressor\Logger;

class Logger extends \Monolog\Logger
{
}