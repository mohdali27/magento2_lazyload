var config = {
    map: {
        '*': {
            cnowlcarousel: 'Solwin_Ournews/js/owl.carousel',
        }
    }
};