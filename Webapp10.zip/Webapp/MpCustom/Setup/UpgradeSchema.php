<?php
/**
 * Webapp Customization
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */
namespace Webapp\MpCustom\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'beneficiary_name',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => '255',
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank Account beneficiary name'
            ]
        );

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'bank_name',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => '255',
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank name'
            ]
        );

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'bank_branch_name',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => '255',
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank branch name'
            ]
        );

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'bank_branch_addr',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank branch address'
            ]
        );

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'account_number',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => '255',
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank Account number'
            ]
        );

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'iban',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => '255',
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank iban code'
            ]
        );

        /**
         * Update tables 'marketplace_userdata'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_userdata'),
            'swift',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => '255',
                'unsigned' => true,
                'nullable' => true,
                'default' => null,
                'comment' => 'Bank swift code'
            ]
        );
        $setup->endSetup();
    }

}
