<?php
/**
 * Webapp Customization.
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Controller\Account;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\App\RequestInterface;

/**
 * Webkul Marketplace Account Save Payment Information Controller.
 */
class SavePaymentInfo extends \Webkul\Marketplace\Controller\Account\SavePaymentInfo
{
    
    /**
     * Seller's SavePaymentInfo action.
     *
     * @return \Magento\Framework\Controller\Result\RedirectFactory
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($this->getRequest()->isPost()) {
            try {
                if (!$this->_formKeyValidator->validate($this->getRequest())) {
                    return $this->resultRedirectFactory->create()->setPath(
                        '*/*/editProfile',
                        ['_secure' => $this->getRequest()->isSecure()]
                    );
                }
                $fields = $this->getRequest()->getParams();
                $sellerId = $this->_getSession()->getCustomerId();
                $collection = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Seller'
                )
                ->getCollection()
                ->addFieldToFilter('seller_id', $sellerId);
                $autoIds = $collection->getAllIds();
                foreach ($autoIds as $autoId) {
                    $value = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')
                    ->load($autoId);
                    $paymetSource = "<p>Beneficiary Name : <b>".$fields['beneficiary_name']."</b></p><p>Bank Name : <b>".$fields['bank_name']."</b></p><p>
                    Bank Branch Name : <b>".$fields['bank_branch_name']."</b></p><p>Bank Branch Address : <b>".$fields['bank_branch_addr']."</b></p><p>Account_number : <b>".$fields['account_number']."</b></p>Iban : <b>".$fields['iban']."</b></p>";
                    if($fields['swift']){
                        $paymetSource.="<p>SWIFT : <b>".$fields['swift']."</b></p>";
                    }
                    $value->setPaymentSource($paymetSource);
                    $value->setBeneficiaryName($fields['beneficiary_name']);
                    $value->setBankName($fields['bank_name']);
                    $value->setBankBranchName($fields['bank_branch_name']);
                    $value->setBankBranchAddr($fields['bank_branch_addr']);
                    $value->setAccountNumber($fields['account_number']);
                    $value->setIban($fields['iban']);
                    $value->setSwift($fields['swift']);

                    $value->setUpdatedAt($this->_date->gmtDate());
                    $value->save();
                }
                // clear cache
                $this->_objectManager->create(
                    'Webkul\Marketplace\Helper\Data'
                )->clearCache();
                $this->messageManager->addSuccess(
                    __('Payment information was successfully saved')
                );

                return $this->resultRedirectFactory->create()->setPath(
                    '*/*/editProfile',
                    ['_secure' => $this->getRequest()->isSecure()]
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());

                return $this->resultRedirectFactory->create()->setPath(
                    '*/*/editProfile',
                    ['_secure' => $this->getRequest()->isSecure()]
                );
            }
        } else {
            return $this->resultRedirectFactory->create()->setPath(
                '*/*/editProfile',
                ['_secure' => $this->getRequest()->isSecure()]
            );
        }
    }
}
