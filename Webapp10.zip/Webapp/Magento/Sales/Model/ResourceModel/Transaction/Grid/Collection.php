<?php
/**
 * Webapp customization.
 */

namespace Webapp\Magento\Sales\Model\ResourceModel\Transaction\Grid;

/**
 * @SuppressWarnings(PHPMD.DepthOfInheritance)
 */
class Collection extends \Magento\Sales\Model\ResourceModel\Transaction\Grid\Collection
{
    /**
     * Resource initialization
     *
     * @return $this
     */
    protected function _initSelect()
    {
       parent::_initSelect();
        $order = $this->registryManager->registry('current_order');
        if ($order) {
            $this->addOrderIdFilter($order->getId());
        }
        $this->addOrderInformation(['increment_id']);
        $this->addOrderInformation(['customer_email']);
        $this->addOrderInformation(['customer_firstname']);
        $this->addOrderInformation(['customer_lastname']);
        $this->addPaymentInformation(['method']);
        return $this;
    }
}
