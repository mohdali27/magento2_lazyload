<?php
namespace Webapp\Marketplace\Model\Plugin\ResourceModel\Customer; 
 
class Grid
{
 
    public static $table = 'customer_grid_flat';
    
    public function afterSearch($intercepter, $collection)
    {
        if ($collection->getMainTable() === $collection->getConnection()->getTableName(self::$table)) {
          
            $joinTable = $collection->getConnection()->getTableName('marketplace_userdata');
            $collection->getSelect()
                ->joinLeft($joinTable, 'main_table.entity_id = marketplace_userdata.seller_id', ['entity_id','is_seller']);
        }
        return $collection;
    }
}
