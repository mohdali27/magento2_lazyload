<?php
/**
 * Webapp marketplace customization and fixes.
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Controller\Order;

/**
 * Override Webkul Marketplace Order Invoice Controller.
 */
class Invoice extends \Webkul\Marketplace\Controller\Order\Invoice
{
    /**
     * Marketplace order invoice controller.
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        // echo "<pre>";print_r($_GET);die('hfgdfdfsdfsdfs');
        $helper = $this->_objectManager->create(
            'Webkul\Marketplace\Helper\Data'
        );
        $isPartner = $helper->isSeller();
        if ($isPartner == 1) {
            if ($order = $this->_initOrder()) {
                //echo "<pre>";print_r($order->getId());die('hfgdfdfsdfsdfs');
                //$this->doInvoiceExecution($order);
                //$this->doAdminShippingInvoiceExecution($order);

                /*Add custom deliver date for seller*/
                $this->doDeliveryDate($order);

                return $this->resultRedirectFactory->create()->setPath(
                    '*/*/view',
                    [
                        'id' => $order->getEntityId(),
                        '_secure' => $this->getRequest()->isSecure(),
                    ]
                );
            } else {
                return $this->resultRedirectFactory->create()->setPath(
                    '*/*/history',
                    ['_secure' => $this->getRequest()->isSecure()]
                );
            }
        } else {
            return $this->resultRedirectFactory->create()->setPath(
                'marketplace/account/becomeseller',
                ['_secure' => $this->getRequest()->isSecure()]
            );
        }
    }

   
    protected function doDeliveryDate($order)
    {
        echo "<pre>";print_r($order->getId());die('h');
    }
}
