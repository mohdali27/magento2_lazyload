<?php

namespace Magecomp\Emailquotepro\Controller\Adminhtml\Emailproductquote;


class InlineEdit
{

}