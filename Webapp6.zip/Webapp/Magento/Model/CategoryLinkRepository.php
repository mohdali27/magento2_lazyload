<?php
/**
 * Webapp customization and fixes.
 *
 * @category  Webapp
 * @package   Webapp_Magento
 * @author    Webapp
 */

namespace Webapp\Magento\Model;

use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\CouldNotSaveException;

class CategoryLinkRepository extends \Magento\Catalog\Model\CategoryLinkRepository
{
    /**
     * {@inheritdoc}
     */
    public function deleteByIds($categoryId, $sku)
    {
        $category = $this->categoryRepository->get($categoryId);
        $product = $this->productRepository->get($sku);
        $productPositions = $category->getProductsPosition();
        $productID = $product->getId();
        if (!isset($productPositions[$productID])) {
            throw new InputException(__('Category does not contain specified product'));
        }
        $backupPosition = $productPositions[$productID];

        /*Commented due to issue in magento core or other custom modules*/
        //unset($productPositions[$productID]);
        //$category->setPostedProducts($productPositions);
        try {

            /*Unlink product category*/
            $this->unlinkCategory($category->getId(), $productID);
            $category->save();
        } catch (\Exception $e) {
            throw new CouldNotSaveException(
                __(
                    'Could not save product "%product" with position %position to category %category',
                    [
                        "product" => $product->getId(),
                        "position" => $backupPosition,
                        "category" => $category->getId()
                    ]
                ),
                $e
            );
        }
        return true;
    }

    /**
    * Delete category link due to magento core or third party issue to save category in edit product.
    */
    public function unlinkCategory($catId, $productId){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('catalog_category_product');
        $sql = "DELETE FROM ".$tableName." WHERE category_id = ".$catId." AND product_id = ".$productId;
        $connection->query($sql);
        $tableName = $resource->getTableName('catalog_url_rewrite_product_category');
        $sql = "Select * FROM ".$tableName." WHERE category_id = ".$catId." AND product_id = ".$productId." ORDER BY url_rewrite_id DESC";
        $result = $connection->fetchAll($sql);
        if(!empty($result)){
            $rewriteId = $result[0]['url_rewrite_id'];
            $tableName = $resource->getTableName('url_rewrite');
            $sql = "DELETE FROM ".$tableName." WHERE url_rewrite_id = ".$rewriteId;
            $connection->query($sql);
            $tableName = $resource->getTableName('catalog_url_rewrite_product_category');
            foreach ($result as $item) {
                $rewriteId = $item['url_rewrite_id'];
                $sql = "DELETE FROM ".$tableName." WHERE url_rewrite_id = ".$rewriteId;
                $connection->query($sql);
            }
        }
    }
}
