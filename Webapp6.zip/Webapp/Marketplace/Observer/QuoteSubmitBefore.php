<?php
/**
 * Webapp customization and fixes
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Webapp QuoteSubmitBefore Observer
 */
class QuoteSubmitBefore implements ObserverInterface
{
    /**
     * Convert quote custom field to order
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
       $quote = $observer->getQuote();
       $order = $observer->getOrder();

       $order->setData('display_notification_status', $quote->getData('display_notification_status'));
    }
}
