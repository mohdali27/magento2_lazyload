<?php
/**
 * Webapp Customization
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */
namespace Webapp\Marketplace\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        /**
         * Update tables 'marketplace_saleperpartner'
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('marketplace_orders'),
            'parent_order',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                'unsigned' => true,
                'nullable' => false,
                'default' => '0',
                'comment' => 'Main Product ID'
            ]
        );

        /**
         * Update tables 'sales_order'
         * Set 0 = N0 / 1 or 2 = Yes, Dispaly order in grid and send order 
         * notification to customer
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('sales_order'),
            'display_notification_status',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                'unsigned' => true,
                'nullable' => false,
                'default' => '0',
                'comment' => 'Set 0 / 1 Dispaly order in grid and send order notification to customer'
            ]
        );

        /**
         * Update tables 'quote'
         * Set 0 = N0 / 1 or 2= Yes, Dispaly order in grid and send order 
         * notification to customer
         */
        $setup->getConnection()->addColumn(
            $setup->getTable('quote'),
            'display_notification_status',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                'unsigned' => true,
                'nullable' => false,
                'default' => '0',
                'comment' => 'Set 0 / 1 Dispaly order in grid and send order notification to customer'
            ]
        );
        $setup->endSetup();
    }

}
