<?php
/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Model\StockActivity;

use Magestore\InventorySuccess\Api\StockActivity\StockTrackerInterface;

class StockTracker implements StockTrackerInterface
{
    
}