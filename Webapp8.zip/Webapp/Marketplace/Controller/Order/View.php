<?php
/**
 * Webapp customization.
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Controller\Order;

/**
 * Webapp Marketplace Order View Controller.
 */
class View extends \Webkul\Marketplace\Controller\Order\View
{
    /**
     * Seller Order View page.
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        /*Add logic to update order status*/
        $post = $this->getRequest()->getPostValue();
        if(!empty($post)){
            $order = $this->_initOrder();
            $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('sales_order_status');
            $sql = "SELECT * from ".$tableName." WHERE status = '".$post['status']."'";
            $result = $connection->fetchAll($sql);
            $label = $result[0]['label'];
            $this->changeStatus($order,'complete',$post['status'],$label);
            $resultPage = $this->_resultPageFactory->create();
            $resultPage->addHandle('marketplace_layout2_order_view');
            $resultPage->getConfig()->getTitle()->set(
                            __('Order #%1', $order->getRealOrderId())
                        );
            return $resultPage;
        }
        $helper = $this->_objectManager->create(
            'Webkul\Marketplace\Helper\Data'
        );
        $isPartner = $helper->isSeller();
        if ($isPartner == 1) {
            if ($order = $this->_initOrder()) {
                /*update notification flag*/
                $this->_updateNotification();
                /** @var \Magento\Framework\View\Result\Page $resultPage */
                $resultPage = $this->_resultPageFactory->create();
                if ($helper->getIsSeparatePanel()) {
                    $resultPage->addHandle('marketplace_layout2_order_view');
                }
                $resultPage->getConfig()->getTitle()->set(
                    __('Order #%1', $order->getRealOrderId())
                );

                return $resultPage;
            } else {
                return $this->resultRedirectFactory->create()->setPath(
                    '*/*/history',
                    ['_secure' => $this->getRequest()->isSecure()]
                );
            }
        } else {
            return $this->resultRedirectFactory->create()->setPath(
                'marketplace/account/becomeseller',
                ['_secure' => $this->getRequest()->isSecure()]
            );
        }
    }

    /**
    * @var $order pass the order model
    * @var $orderState pass the state for the order
    * @var $orderStatus pass the status for the order
    * @var $orderLabel pass the status label
    **/
    // $orderLabel is Ready
    public function changeStatus($order,$orderState, $orderStatus, $orderLabel)
    {            
           $order->setState($orderState)->setStatus($orderStatus);
           $order->save();
           $history = $order->addStatusHistoryComment('Order is : '.$orderLabel, $order->getStatus());
           $history->setIsCustomerNotified(true);
           $history->save(); 

           /*Send email*/
           /** @var OrderCommentSender $orderCommentSender */
           $orderCommentSender = $this->_objectManager
               ->create(\Magento\Sales\Model\Order\Email\Sender\OrderCommentSender::class);

           $orderCommentSender->send($order, true, '');
    }
}
