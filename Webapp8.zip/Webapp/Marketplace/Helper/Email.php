<?php
/**
 * Webapp customization.
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Helper;

use Magento\Customer\Model\Session;
use Magento\Framework\Exception\MailException;

/**
 * Webapp Marketplace Helper Email.
 */
class Email extends \Webkul\Marketplace\Helper\Email
{
    /**
     * [sendSellerApproveMail description].
     *
     * @param Mixed $emailTemplateVariables
     * @param Mixed $senderInfo
     * @param Mixed $receiverInfo
     */
    public function sendSellerApproveMail($emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        $this->_template = $this->getTemplateId(self::XML_PATH_EMAIL_SELLER_APPROVAL);
        $this->_inlineTranslation->suspend();
        $this->generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo);
        try {
            $transport = $this->_transportBuilder->getTransport();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $conf = $objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('marketplace/general_settings/pdf');
            if($conf){
                $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
                $pub = $directory->getPath('pub');
                $pdfFile = $pub.'/media/marketplace/'.$conf;
                $transport->addAttachment(file_get_contents($pdfFile))->sendMessage();
            } else {
                $transport->sendMessage();
            }
        } catch (\Exception $e) {
            $this->_messageManager->addError($e->getMessage());
        }
        $this->_inlineTranslation->resume();
    }
}
