<?php
/**
 * Webapp Customization
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManager;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Webkul\Marketplace\Helper\Data as MarketplaceHelper;
use Webkul\Marketplace\Helper\Notification as NotificationHelper;

/**
 * Override Webkul Marketplace SalesOrderSuccessObserver Observer Model.
 */
class SalesOrderSuccessObserver extends \Webkul\Marketplace\Observer\SalesOrderSuccessObserver
{
    
    /**
     * Sales Order Place After event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getOrderIds();
        foreach ($orderIds as $lastOrderId) {
            $sellerOrder = $this->_objectManager->create(
                'Webkul\Marketplace\Model\Orders'
            )
            ->getCollection()
            ->addFieldToFilter('order_id', $lastOrderId);

             
            /*Add logic to split orders*/
            $this->splitOrder($lastOrderId, $sellerOrder);

            if (!count($sellerOrder)) {
                /** @var $orderInstance Order */
                $order = $this->_orderRepository->get($lastOrderId);
                $this->orderPlacedOperations($order, $lastOrderId);
            }
        }
    }
    

    /**
     * split orders based on sellers.
     *
     * @param Integer $orderId
     * @param \Webkul\Marketplace\Model\Orders $sellerOrders
    */
    public function splitOrder($orderId, $sellerOrders)
    {
        $createOrderHelper = $this->_objectManager->create(
                'Webapp\Marketplace\Helper\Data'
            );
        if(count($sellerOrders->getData()) > 1 && $orderId){
            $sellerOrders = $sellerOrders->getData();
            $test = array();
            $_SESSION["splitOrdersId"] = array();
            $realPaymet = $this->getMainOrderPayment($orderId);
            foreach ($sellerOrders as $key => $orderdata) {
                $formatedData = $this->formateOrderData($orderdata);
                $test[] = $formatedData;
                $result = $createOrderHelper->createOrder($formatedData);
                if($result['order_id']){
                    $sellerOrder = $this->_objectManager->create('Webkul\Marketplace\Model\Orders')->load($orderdata['entity_id']);
                    $mainOrderId = $sellerOrder->getOrderId();
                    $sellerOrder->setParentOrder($mainOrderId);
                    $sellerOrder->setOrderId(0);
                    $sellerOrder->save();

                    /*Set main order id as parent id*/
                    $sellerSplitOrder = $this->_objectManager->create('Webkul\Marketplace\Model\Orders')
                        ->getCollection()
                        ->addFieldToFilter('order_id', $result['order_id']);
                    if(count($sellerSplitOrder)){
                        foreach ($sellerSplitOrder as $splitOrder) {
                            $splitOrder->setParentOrder($mainOrderId);
                            $splitOrder->save();
                        }
                    }

                    /*Update payment information*/
                    if(!empty($realPaymet)){
                        $this->updateOrderPayment($result['order_id'],$realPaymet[0]);
                    }
                }
            }
            //$Realpaymet = $this->getMainOrderPayment($result['order_id']);
            //echo "<pre>";print_r($paymet);die;
        }
    }

    /**
     * Get paymet information.
     *
     * @param int $orderId
    */

     public function getMainOrderPayment($orderId){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('sales_order_payment');
        $sql = "SELECT * from ".$tableName." WHERE parent_id = ".$orderId;
        $result = $connection->fetchAll($sql);
        return $result;
     }

     /**
     * Update paymet information.
     *
     * @param int $orderId
     * @param array $info
    */

     public function updateOrderPayment($orderId, $info){
        $method = $info['method'];
        $last_trans_id = $info['last_trans_id'];
        $cc_trans_id = $info['cc_trans_id'];
        $additional_information = $info['additional_information'];
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('sales_order_payment');
        $sql = "UPDATE ".$tableName." SET method = '".$method."', last_trans_id = '".$last_trans_id."', cc_trans_id = '".$cc_trans_id."', additional_information = '".$additional_information."' WHERE parent_id = ".$orderId;
       $connection->query($sql);
     }

    /**
     * Formate seller order data.
     *
     * @param \Webkul\Marketplace\Model\Orders $sellerOrders
    */

    public function formateOrderData($sellerOrder)
    {
        $order =  $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($sellerOrder['order_id']);
        
        $paymentCode = '';
        if ($order->getPayment()) {
            $paymentCode = $order->getPayment()->getMethod();
        }
        $shippingMethod = '';
        if ($order->getShippingMethod()) {
            $shippingMethod = $order->getShippingMethod();
        }
        $currencyCode = $order->getOrderCurrencyCode();
        $email = $order->getCustomerEmail();
        $firstname = $order->getBillingAddress()->getFirstname();
        $lastname= $order->getBillingAddress()->getLastname();
         
        //$billingAddress = $order->getBillingAddress()->getData();
        $street = $order->getBillingAddress()->getStreet();
        $city = $order->getBillingAddress()->getCity(); 
        $country_id = $order->getBillingAddress()->getCountryId();
        $region_id = $order->getBillingAddress()->getRegionId();
        $region = $order->getBillingAddress()->getRegion();
        $postcode = $order->getBillingAddress()->getPostcode(); 
        $telephone = $order->getBillingAddress()->getTelephone(); 
        $fax = $order->getBillingAddress()->getFax();
        /*if ($order->getShippingAddress()) {
            $shippingId = $order->getShippingAddress()->getId();
            $address = $this->_objectManager->create(
                'Magento\Sales\Model\Order\Address'
            )->load($shippingId);
            $street = @$address['street'];
            $city = @$address['city'];
            $country_id = @$address['country_id'];
            $region = @$address['region'];
            $postcode = @$address['postcode'];
            $telephone = @$address['telephone'];
            $fax = @$address['fax'];
        }*/
        $items = array();
        $productsIds = explode(',', $sellerOrder['product_ids']);
        foreach ($order->getAllItems() as $item) {
            $itemData = $item->getData();
            if(in_array($itemData['product_id'], $productsIds)){
                $items[] = $item->getData();
            }
        }

        
        if(!empty($items)){
            $Orderdata=[
                'currency_id'  => $currencyCode,
                'email'        => $email, //buyer email id
                'shippingMethod' => $shippingMethod,
                'paymentMethod'  => $paymentCode,
                'shipping_address' =>[
                    'firstname'    => $firstname,
                    'lastname'     => $lastname,
                    'street' => $street,
                    'city' => $city,
                    'country_id' => $country_id,
                    'region_id' => $region_id,
                    'region' => $region,
                    'postcode' => $postcode,
                    'telephone' => $telephone,
                    'fax' => $fax,
                    'save_in_address_book' => 1
                    ],
               'items'=> $items
            ];
            return $Orderdata;
        }
    }

    /**
     * Order Place Operation method.
     *
     * @param \Magento\Sales\Model\Order $order
     * @param int                        $lastOrderId
     */
    public function orderPlacedOperations($order, $lastOrderId)
    {
        $this->productSalesCalculation($order);

        /*send placed order mail notification to seller*/

        $paymentCode = '';
        if ($order->getPayment()) {
            $paymentCode = $order->getPayment()->getMethod();
        }

        $shippingInfo = '';
        $shippingDes = '';

        $billingId = $order->getBillingAddress()->getId();

        $billaddress = $this->_objectManager->create(
            'Magento\Sales\Model\Order\Address'
        )->load($billingId);
        $billinginfo = $billaddress['firstname'].'<br/>'.
        $billaddress['street'].'<br/>'.
        $billaddress['city'].' '.
        $billaddress['region'].' '.
        $billaddress['postcode'].'<br/>'.
        $this->_objectManager->create(
            'Magento\Directory\Model\Country'
        )->load($billaddress['country_id'])->getName().'<br/>T:'.
        $billaddress['telephone'];

        $order->setOrderApprovalStatus(1)->save();

        $payment = $order->getPayment()->getMethodInstance()->getTitle();

        if ($order->getShippingAddress()) {
            $shippingId = $order->getShippingAddress()->getId();
            $address = $this->_objectManager->create(
                'Magento\Sales\Model\Order\Address'
            )->load($shippingId);
            $shippingInfo = $address['firstname'].'<br/>'.
            $address['street'].'<br/>'.
            $address['city'].' '.
            $address['region'].' '.
            $address['postcode'].'<br/>'.
            $this->_objectManager->create(
                'Magento\Directory\Model\Country'
            )->load($address['country_id'])->getName().'<br/>T:'.
            $address['telephone'];
            $shippingDes = $order->getShippingDescription();
        }

        $adminStoremail = $this->_marketplaceHelper->getAdminEmailId();
        $defaultTransEmailId = $this->_marketplaceHelper->getDefaultTransEmailId();
        $adminEmail = $adminStoremail ? $adminStoremail : $defaultTransEmailId;
        $adminUsername = 'Admin';

        $sellerOrder = $this->_objectManager->create(
            'Webkul\Marketplace\Model\Orders'
        )
        ->getCollection()
        ->addFieldToFilter('order_id', $lastOrderId)
        ->addFieldToFilter('seller_id', ['neq' => 0]);
        
        // Send email to seller only for split order
        if(count($sellerOrder->getData()) == 1) {
            foreach ($sellerOrder as $info) {
                $userdata = $this->_customerRepository->getById($info['seller_id']);
                $username = $userdata->getFirstname();
                $useremail = $userdata->getEmail();

                $senderInfo = [];
                $receiverInfo = [];

                $receiverInfo = [
                    'name' => $username,
                    'email' => $useremail,
                ];
                $senderInfo = [
                    'name' => $adminUsername,
                    'email' => $adminEmail,
                ];
                $totalprice = 0;
                $totalTaxAmount = 0;
                $codCharges = 0;
                $shippingCharges = 0;
                $orderinfo = '';

                $saleslistIds = [];
                $collection1 = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Saleslist'
                )->getCollection()
                ->addFieldToFilter('order_id', $lastOrderId)
                ->addFieldToFilter('seller_id', $info['seller_id'])
                ->addFieldToFilter('parent_item_id', ['null' => 'true'])
                ->addFieldToFilter('magerealorder_id', ['neq' => 0])
                ->addFieldToSelect('entity_id');

                $saleslistIds = $collection1->getData();

                $fetchsale = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Saleslist'
                )
                ->getCollection()
                ->addFieldToFilter(
                    'entity_id',
                    ['in' => $saleslistIds]
                );
                $fetchsale->getSellerOrderCollection();
                foreach ($fetchsale as $res) {
                    /* product name */
                    $productName = $res->getMageproName();
                    $result = [];
                    $result = $this->getProductOptionData($res, $result);
                    $productName = $this->getProductNameHtml($result, $productName);
                    /* end */
                    if ($res->getProductType() == 'configurable') {
                        $configurableSalesItem = $this->_objectManager->create(
                            'Webkul\Marketplace\Model\Saleslist'
                        )->getCollection()
                        ->addFieldToFilter('order_id', $lastOrderId)
                        ->addFieldToFilter('seller_id', $info['seller_id'])
                        ->addFieldToFilter('parent_item_id', $res->getOrderItemId());
                        $configurableItemArr = $configurableSalesItem->getOrderedProductId();
                        $configurableItemId = $res['mageproduct_id'];
                        if (!empty($configurableItemArr)) {
                            $configurableItemId = $configurableItemArr[0];
                        }
                        $product = $this->_productRepository->getById($configurableItemId);
                    } else {
                        $product = $this->_productRepository->getById($res['mageproduct_id']);
                    }

                    $sku = $product->getSku();
                    $orderinfo = $orderinfo."<tbody><tr>
                                    <td class='item-info'>".$productName."</td>
                                    <td class='item-info'>".$sku."</td>
                                    <td class='item-qty'>".($res['magequantity'] * 1)."</td>
                                    <td class='item-price'>".
                                        $order->formatPrice(
                                            $res['magepro_price'] * $res['magequantity']
                                        ).
                                    '</td>
                                 </tr></tbody>';
                    $totalTaxAmount = $totalTaxAmount + $res['total_tax'];
                    $totalprice = $totalprice + ($res['magepro_price'] * $res['magequantity']);

                    /*
                    * Low Stock Notification mail to seller
                    */
                    if ($this->_marketplaceHelper->getlowStockNotification()) {
                        if (!empty($product['quantity_and_stock_status']['qty'])) {
                            $stockItemQty = $product['quantity_and_stock_status']['qty'];
                        } else {
                            $stockItemQty = $product->getQty();
                        }
                        if ($stockItemQty <= $this->_marketplaceHelper->getlowStockQty()) {
                            $orderProductInfo = "<tbody><tr>
                                    <td class='item-info'>".$productName."</td>
                                    <td class='item-info'>".$sku."</td>
                                    <td class='item-qty'>".($stockItemQty * 1).'</td>
                                 </tr></tbody>';

                            $emailTemplateVariables = [];
                            $emailTemplateVariables['myvar1'] = $orderProductInfo;
                            $emailTemplateVariables['myvar2'] = $username;

                            $this->_objectManager->get(
                                'Webkul\Marketplace\Helper\Email'
                            )->sendLowStockNotificationMail(
                                $emailTemplateVariables,
                                $senderInfo,
                                $receiverInfo
                            );
                        }
                    }
                }
                $shippingCharges = $info->getShippingCharges();
                $couponAmount = $info->getCouponAmount();
                $totalCod = 0;

                if ($paymentCode == 'mpcashondelivery') {
                    $totalCod = $info->getCodCharges();
                    $codRow = "<tr class='subtotal'>
                                <th colspan='3'>".__('Cash On Delivery Charges')."</th>
                                <td colspan='3'><span>".
                                    $order->formatPrice($totalCod).
                                '</span></td>
                                </tr>';
                } else {
                    $codRow = '';
                }

                $orderinfo = $orderinfo."<tfoot class='order-totals'>
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Shipping & Handling Charges')."</th>
                                        <td colspan='3'><span>".
                                        $order->formatPrice($shippingCharges)."</span></td>
                                    </tr>
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Discount')."</th>
                                        <td colspan='3'><span> -".
                                            $order->formatPrice($couponAmount).
                                        "</span></td>
                                    </tr>
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Tax Amount')."</th>
                                        <td colspan='3'><span>".
                                        $order->formatPrice($totalTaxAmount).'</span></td>
                                    </tr>'.$codRow."
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Grandtotal')."</th>
                                        <td colspan='3'><span>".
                                        $order->formatPrice(
                                            $totalprice +
                                            $totalTaxAmount +
                                            $shippingCharges +
                                            $totalCod -
                                            $couponAmount
                                        ).'</span></td>
                                    </tr></tfoot>';

                $emailTemplateVariables = [];
                if ($shippingInfo != '') {
                    $isNotVirtual = 1;
                } else {
                    $isNotVirtual = 0;
                }
                $emailTempVariables['myvar1'] = $order->getRealOrderId();
                $emailTempVariables['myvar2'] = $order['created_at'];
                $emailTempVariables['myvar4'] = $billinginfo;
                $emailTempVariables['myvar5'] = $payment;
                $emailTempVariables['myvar6'] = $shippingInfo;
                $emailTempVariables['isNotVirtual'] = $isNotVirtual;
                $emailTempVariables['myvar9'] = $shippingDes;
                $emailTempVariables['myvar8'] = $orderinfo;
                $emailTempVariables['myvar3'] = $username;

                if ($this->_marketplaceHelper->getOrderApprovalRequired()) {
                    $emailTempVariables['seller_id'] = $info['seller_id'];
                    $emailTempVariables['order_id'] = $lastOrderId;
                    $emailTempVariables['sender_name'] = $senderInfo['name'];
                    $emailTempVariables['sender_email'] = $senderInfo['email'];
                    $emailTempVariables['receiver_name'] = $receiverInfo['name'];
                    $emailTempVariables['receiver_email'] = $receiverInfo['email'];

                    $orderPendingMailsCollection = $this->_objectManager->create(
                        'Webkul\Marketplace\Model\OrderPendingMails'
                    );
                    $orderPendingMailsCollection->setData($emailTempVariables);
                    $orderPendingMailsCollection->setCreatedAt($this->_date->gmtDate());
                    $orderPendingMailsCollection->setUpdatedAt($this->_date->gmtDate());
                    $orderPendingMailsCollection->save();
                    $order->setOrderApprovalStatus(0)->save();
                } else {
                    $this->_objectManager->get(
                        'Webkul\Marketplace\Helper\Email'
                    )->sendPlacedOrderEmail(
                        $emailTempVariables,
                        $senderInfo,
                        $receiverInfo
                    );
                }
            }
        }
    }
}
