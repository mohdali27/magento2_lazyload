var config = {
    map: {
        '*': {
            taxjarClipboard: 'Taxjar_SalesTax/js/clipboard',
            taxjarPopup: 'Taxjar_SalesTax/js/popup'
        }
    }
};
