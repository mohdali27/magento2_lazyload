<?php
/**
 * Webapp customization and fixes
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */
namespace Webapp\Marketplace\Model\ResourceModel\Order\Grid;

use Magento\Sales\Model\ResourceModel\Order\Grid\Collection as OriginalCollection;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface as FetchStrategy;
use Magento\Framework\Data\Collection\EntityFactoryInterface as EntityFactory;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Psr\Log\LoggerInterface as Logger;

/**
 * Override sales grid collection to filter out main order .
 */
class Collection extends OriginalCollection
{
    protected function _renderFiltersBefore() {
        $joinTable = $this->getTable('sales_order');
        $this->getSelect()->join($joinTable, 'main_table.entity_id = sales_order.entity_id', ['entity_id','display_notification_status']);
        $this->getSelect()->where("sales_order.display_notification_status = 1");
        parent::_renderFiltersBefore();
    }
}
