<?php

namespace Webapp\Marketplace\Model;

use \Psr\Log\LoggerInterface;
use \Magento\Framework\Phrase;
use \Magento\Framework\Mail\MessageInterface;
use \Magento\Framework\Exception\MailException;
use \Magento\Framework\Mail\TransportInterface;
use \Magento\Framework\Module\Manager;
use SendGrid\EmailDeliverySimplified\Helper\API;
use SendGrid\EmailDeliverySimplified\Helper\Tools;
use SendGrid\EmailDeliverySimplified\Model\GeneralSettings;

class Transport extends \SendGrid\EmailDeliverySimplified\Model\Transport
{
    /**
     * @param Api\AttachmentInterface $attachment
     */
    public function addAttachment($pdfString)
    {
        $this->_message->createAttachment(
            $pdfString,
            'application/pdf',
            \Zend_Mime::DISPOSITION_ATTACHMENT,
            \Zend_Mime::ENCODING_BASE64,
            'attatched.pdf'
        );
        return $this;
    }
}
