<?php
namespace Webapp\Marketplace\Ui\Component\Listing;
class CustomerDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult
{
    protected function _initSelect()
    {
        parent::_initSelect();
        $this->getSelect()->joinLeft
        (
            ['custom_table_name' => $this->getTable('marketplace_userdata')],
            'main_table.entity_id = custom_table_name.seller_id',
            ['is_seller']
        );
        return $this;
    }
}
