<?php
/**
 * @Copyright � FME fmeextensions.com. All rights reserved.
 * @autor Tahir Mehmood <tahir.mehmood@unitedsol.net>
 * @package FME InvoiceEmail
 * @license See COPYING.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'FME_InvoiceEmail',
    __DIR__
);
