/**
 *
 * @category : FME
 * @Package  : FME_CheckoutOrderAttributesFields
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */

define([
  'jquery',
  'mage/utils/wrapper',
  'Magento_Checkout/js/model/quote',
  'mage/validation'
], function ($, wrapper, quote) {
  'use strict';

  return function (placeOrderAction) {
    return wrapper.wrap(placeOrderAction, function (originalAction) {
      
      
      var billingAddress = quote.billingAddress();
      var paymentMethod = quote.paymentMethod();

      try {
        if (billingAddress.customAttributes === undefined) {
          return originalAction();
        }
        if (billingAddress.extensionAttributes === undefined) {
          billingAddress.extensionAttributes = {};
        }
        if (billingAddress.customAttributes.invoice_email === undefined || !billingAddress.customAttributes.invoice_email) {
          return originalAction();
        }
        if (billingAddress.extensionAttributes.invoice_email === undefined) {
          billingAddress.extensionAttributes.invoice_email = '';
        }
        billingAddress.extensionAttributes.invoice_email =  billingAddress.customAttributes.invoice_email;
      } catch (e) {
        return originalAction();
      }
      return originalAction();
    });
  };
});