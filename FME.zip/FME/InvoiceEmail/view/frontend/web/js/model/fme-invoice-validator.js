/**
 *
 * @category : FME
 * @Package  : FME_CheckoutOrderAttributesFields
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */

define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'mage/validation'
], function ($,quote) {
    'use strict';
    return {
        /**
         * Validate something
         *
         * @returns {boolean}
         */
        validate: function () {
            var validfields = true;
            $('#invoice-checkout-form button.action').click();
            if ($('#invoice-checkout-form .validate-fme-fields') && $('#invoice-checkout-form .validate-fme-fields').hasClass('_error')) {
                validfields = false;
                $('html, body').animate({
                    scrollTop: $('#invoice-checkout-form .validate-fme-fields._error').offset().top + 'px'
                }, 'slow');
            }
            return validfields;
        }
    }
});
