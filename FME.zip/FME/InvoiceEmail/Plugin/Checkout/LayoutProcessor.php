<?php
/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */
namespace FME\InvoiceEmail\Plugin\Checkout;

class LayoutProcessor
{
    /**
     * @var \FME\InvoiceEmail\Helper\Attributes
     */
    private $helper;
    /**
     * @var \FME\InvoiceEmail\Helper\Data
     */
    private $dataHelper;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;
    
    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;
    
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;
    
    /**
     * Data constructor.
     *
     * @param \FME\InvoiceEmail\Helper\Attributes $helper
     * @param \FME\InvoiceEmail\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\Session\Proxy $customerSession
     * @param \Magento\Checkout\Model\Session\Proxy $checkoutSession
     */
    public function __construct(
        \FME\InvoiceEmail\Helper\Data $dataHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session\Proxy $customerSession,
        \Magento\Checkout\Model\Session\Proxy $checkoutSession
    ) {
        $this->dataHelper   = $dataHelper;
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * @param \Magento\Checkout\Block\Checkout\LayoutProcessor $subject
     * @param array $jsLayout
     * @return array
     */
    public function afterProcess(
        \Magento\Checkout\Block\Checkout\LayoutProcessor $subject,
        array $jsLayout
    ) {
        if ($this->dataHelper->getStatus()) {
            
            $value = '';
            if ($this->customerSession->isLoggedIn()) {
                $customer = $this->customerSession->getCustomer();
                $value = $this->dataHelper->getSavedValue($customer->getId());
            }
            if (!isset(
                $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
                ['payment']['children']['afterForm']['children']['invoice-form-container']
            )) {
                $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']
                ['children']['payment']['children']['afterForm'] =
                [
                    'component' => 'uiComponent',
                    'displayArea' => 'afterForm',
                    'children' =>
                    [
                        'invoice-form-container' => [
                            'component' => 'FME_InvoiceEmail/js/view/invoice-checkout-form',
                            'provider' => 'checkoutProvider',
                            'config' => [
                                'template'=>'FME_InvoiceEmail/invoice-checkout-form'
                            ],
                            'children'=> [
                                'invoice-checkout-form-fieldset' => [
                                    'component' => 'uiComponent',
                                    'displayArea' => 'invoice-checkout-form-fields',
                                    'children'=>[
                                        
                                    ]
                                ]
                            ]
                        ]
                    ]
                ];
            }
            $elementConfig['sortOrder'] = 0;
            $elementConfig['dataScope'] = 'invoice_email';
            $elementConfig['customScope'] = 'invoice_email';
            $elementConfig['id'] = 'invoice_email';
            $elementConfig['value'] = $value;
            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
            ['payment']['children']['afterForm']['children']['invoice-form-container']['children']
            ['invoice-checkout-form-fieldset']['children']
            ['invoice_email'] = $this->getAttributeConfig($elementConfig);
            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
            ['payment']['children']['additional-payment-validators']['children']['fme-invoice-validator']
            ['component']='FME_InvoiceEmail/js/view/fme-invoice-validation';
        }
        return $jsLayout;
    }
    
    /**
     * @param array $attribute
     * @param array $scope
     * @param boolean $mayBeHidden
     * @return array
     */
    public function getAttributeConfig($scope)
    {
        $validationClass['validate-email'] = 'true';

        $attributeConfig = [
            'component' => 'Magento_Ui/js/form/element/abstract',
            'config' => [
                'additionalClasses' => 'validate-fme-fields',
                'customScope' => $scope['customScope'],
                'template' => 'ui/form/field',
                'elementTmpl' => 'ui/form/element/input',
            ],
            'dataScope' => $scope['dataScope'],
            'label' => $this->dataHelper->getHeading(),
            'provider' => 'checkoutProvider',
            'visible' => true,
            'validation' => $validationClass,
            'sortOrder' => $scope['sortOrder'],
            'value' => $scope['value'],
            'id' => 'invoice_email'
        ];  
        return $attributeConfig;
    }
}
