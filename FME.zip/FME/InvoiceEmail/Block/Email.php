<?php
/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 © fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */

namespace FME\InvoiceEmail\Block;

use Magento\Backend\Block\Template\Context;
use Magento\Customer\Api\CustomerRepositoryInterface;

class Email extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \FME\InvoiceEmail\Helper\Data
     */
    private $helper;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;
    
    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;
    
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;
    /** @var CustomerRepositoryInterface */
    private $customerRepository;
    
    /**
     * Data constructor.
     *
     * @param \FME\InvoiceEmail\Helper\Data $helper
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\Session\Proxy $customerSession
     */
    public function __construct(
        Context $context,
        \FME\InvoiceEmail\Helper\Data $helper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\Session\Proxy $customerSession,
        CustomerRepositoryInterface $customerRepository,
        array $data = []
    ) {
        $this->helper       = $helper;
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->customerRepository = $customerRepository;
        parent::__construct($context, $data);
    }
    
    public function isAllowed()
    {
        if ($this->helper->getStatus()) {
            return true;
        }
        return false;
    }
    
    public function isAllowedOnRegistration()
    {
        if ($this->helper->getStatus() && $this->helper->getRegistrationStatus()) {
            return true;
        }
        return false;
    }
    
    public function getHeading()
    {
        return $this->helper->getHeading();
    }

    public function getSavedValue()
    {
        $customerId = $this->customerSession->getCustomer()->getId();
        $customer = $this->customerRepository->getById($customerId);
        if ($customer->getCustomAttribute('invoice_email')) {
            return $customer->getCustomAttribute('invoice_email')->getValue();
        }
        return;
    }
    /**
     * Get form action URL for POST booking request
     *
     * @return string
     */
    public function getPostUrl()
    {
        return $this->getUrl('invoiceemail/customer/postData');
    }
}
