<?php
/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */
namespace FME\InvoiceEmail\Controller\Customer;

use Magento\Contact\Model\ConfigInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\ForwardFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;

class PostData extends \Magento\Framework\App\Action\Action
{
    /** @var CustomerRepositoryInterface */
    private $customerRepository;
    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;
    
    /**
     * @var \FME\GDPR\Helper\Data
     */
    private $helper;

    /**
     * @var PageFactory
     */
    private $urlInterface;
    private $formKeyValidator;

    /**
     * @param Context     $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \FME\InvoiceEmail\Helper\Data $helper,
        \Magento\Customer\Model\Session\Proxy $customerSession,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        CustomerRepositoryInterface $customerRepository
    ) {

        $this->helper           = $helper;
        $this->customerSession  = $customerSession;
        $this->urlInterface     = $urlInterface;
        $this->customerRepository = $customerRepository;
        $this->formKeyValidator = $formKeyValidator;
        parent::__construct($context);
    }//end __construct()
    
    /**
     * Dispatch request
     *
     * @param RequestInterface $request
     * @return \Magento\Framework\App\ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function dispatch(RequestInterface $request)
    {
        if (!$this->helper->getStatus()) {
            throw new NotFoundException(__('Page disabled found.'));
        }
        if (!$this->customerSession->isLoggedIn()) {
            $this->customerSession->setAfterAuthUrl($this->urlInterface->getCurrentUrl());
            $this->customerSession->authenticate();
            $this->_actionFlag->set('', self::FLAG_NO_DISPATCH, true);
            $this->customerSession->setBeforeAuthUrl($this->urlInterface->getCurrentUrl());
        }
        return parent::dispatch($request);
    }
    /**
     * Customer order history
     *
     * @return \Magento\Framework\View\Result\Page $resultPage
     */
    public function execute()
    {
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addError(__('Invalid request, please try again later.'));
            $this->_redirect('invoiceemail/customer/email');
            return;
        }
        $post = (array) $this->getRequest()->getPost();
        if (empty($post) || !isset($post['invoice_email'])) {
            $this->messageManager->addError(__('Changes were failed to update, please try again.'));
            $this->_redirect('invoiceemail/customer/email');
            return;
        }
        $customerId = $this->customerSession->getCustomer()->getId();
        $customer = $this->customerRepository->getById($customerId);
        //set customer custom attribute value
        $customer->setCustomAttribute('invoice_email',$post['invoice_email']);
        try {                
            $customer = $this->customerRepository->save($customer);
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->messageManager->addSuccess(__('Your changes were successfully updated.'));
        $this->_redirect('invoiceemail/customer/email');
        return;
    }//end execute()
}//end class
