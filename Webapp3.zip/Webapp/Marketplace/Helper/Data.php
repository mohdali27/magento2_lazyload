<?php
namespace Webapp\Marketplace\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
   /**
    * @param Magento\Framework\App\Helper\Context $context
    * @param Magento\Store\Model\StoreManagerInterface $storeManager
    * @param Magento\Catalog\Model\Product $product,
    * @param Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface,
    * @param Magento\Quote\Api\CartManagementInterface $cartManagementInterface,
    * @param Magento\Customer\Model\CustomerFactory $customerFactory,
    * @param Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
    * @param Magento\Sales\Model\Order $order
    */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Model\Product $product,
        \Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface,
        \Magento\Quote\Api\CartManagementInterface $cartManagementInterface,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Sales\Model\Order $order,
        \Magento\CatalogInventory\Api\StockStateInterface $stockStateInterface,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry, 
        \Magento\CatalogInventory\Observer\ItemsForReindex $itemsForReindex,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Quote\Model\QuoteManagement $quoteManagement
    ) {
        $this->_storeManager = $storeManager;
        $this->_product = $product;
        $this->cartRepositoryInterface = $cartRepositoryInterface;
        $this->cartManagementInterface = $cartManagementInterface;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->order = $order;
        $this->_stockStateInterface = $stockStateInterface;
        $this->_stockRegistry = $stockRegistry;
        $this->itemsForReindex = $itemsForReindex;
        $this->_objectManager = $objectManager;
        $this->quoteManagement = $quoteManagement;
        parent::__construct($context);
    }
 
    /**
     * Create Order On Your Store
     * 
     * @param array $orderData
     * @return array
     * 
    */
    public function createOrder($orderData) {
        //die('createorderhelper');
        $store=$this->_storeManager->getStore();
        $websiteId = $this->_storeManager->getStore()->getWebsiteId();
        $customer=$this->customerFactory->create();
        $customer->setWebsiteId($websiteId);
        $customer->loadByEmail($orderData['email']);// load customet by email address
        if(!$customer->getEntityId()){
            //If not avilable then create this customer 
            $customer->setWebsiteId($websiteId)
                    ->setStore($store)
                    ->setFirstname($orderData['shipping_address']['firstname'])
                    ->setLastname($orderData['shipping_address']['lastname'])
                    ->setEmail($orderData['email']) 
                    ->setPassword($orderData['email'])
                    ->setCustomerIsGuest(1);
            $customer->save();
        }
         
        $cartId = $this->cartManagementInterface->createEmptyCart(); //Create empty cart
        $quote = $this->cartRepositoryInterface->get($cartId); // load empty cart quote
        $quote->setStore($store);
        // if you have allready buyer id then you can load customer directly 
        //if($customer->getEntityId()){
           $customer= $this->customerRepository->getById($customer->getEntityId());
        //}
        $quote->setCurrency();
        $quote->assignCustomer($customer); //Assign quote to customer
 
        //add items in quote
        foreach($orderData['items'] as $item){
            $product=$this->_objectManager->create('\Magento\Catalog\Model\Product')->load($item['product_id']);
            /*$product->setStockData(['qty' => intval($item['qty_ordered']), 'is_in_stock' => 1]);
            $product->setQuantityAndStockStatus(['qty' => intval($item['qty_ordered']), 'is_in_stock' => 1]);
            $stockItem=$this->_stockRegistry->getStockItem($item['product_id']); // load stock of that product
            $stockItem->setData('is_in_stock',1); //set updated data as your requirement
            $stockItem->setData('qty',intval($item['qty_ordered'])); //set updated quantity 
            $stockItem->setData('manage_stock',1);
            $stockItem->setData('use_config_notify_stock_qty',1);
            $stockItem->save();
            $product->save();
            $product=$this->_objectManager->create('\Magento\Catalog\Model\Product')->load($item['product_id']);*/
            if(isset($item['product_options']) && !empty($item['product_options'])) {
                /* for configurable product */
                //$product->setPrice($item['price']);
                //$buyRequest = new \Magento\Framework\DataObject($item);
                $buyRequest = new \Magento\Framework\DataObject($item['product_options']['info_buyRequest']);
                $quote->addProduct($product,$buyRequest);
            } else {
                /* for simple product */
                //$product->setPrice($item['price']);
                $quote->addProduct($product, intval($item['qty_ordered']));
            }
        }
 
        //Set Address to quote
        $quote->getBillingAddress()->addData($orderData['shipping_address']);
        $quote->getShippingAddress()->addData($orderData['shipping_address']);
 
        // Collect Rates and Set Shipping & Payment Method
        $shippingMehod = $orderData['shippingMethod'] ? $orderData['shippingMethod'] : 'freeshipping_freeshipping';
        $shippingAddress=$quote->getShippingAddress();
        $shippingAddress->setCollectShippingRates(true)
                        ->collectShippingRates()
                        ->setShippingMethod($shippingMehod); //shipping method
        $quote->setPaymentMethod($orderData['paymentMethod']); //payment method
        $quote->setInventoryProcessed(false); //not effetc inventory
        /*$quote->setInventoryProcessed(true);
        $itemsForReindex = [];
        $this->itemsForReindex->setItems($itemsForReindex);*/
 
        // Set Sales Order Payment
        $quote->getPayment()->importData(['method' => $orderData['paymentMethod']]);
        $quote->setDisplayNotificationStatus(1);

        $quote->save(); //Now Save quote and your quote is ready

        
        // Collect Totals
        $quote->collectTotals();
 
        // Create Order From Quote
        $quote = $this->cartRepositoryInterface->get($quote->getId());
        $orderId = $this->cartManagementInterface->placeOrder($quote->getId());
        $order = $this->order->load($orderId);
        //$order->setDisplayNotificationStatus(1);
        //$order->save();
        //$order->setEmailSent(0);
        $increment_id = $order->getRealOrderId();
        if($order->getEntityId()){
            $result['order_id']= $order->getId();
        }else{
            $result['order_id'] = 0;
        }
        return $result;
    }
}
