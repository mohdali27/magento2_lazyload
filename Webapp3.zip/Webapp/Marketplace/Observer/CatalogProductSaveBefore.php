<?php
/**
 * Webapp customization and fixes
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Webapp SalesOrderBeforeObserver Observer Model.
 */
class CatalogProductSaveBefore implements ObserverInterface
{
    /**
     * @int product entity attribute id.
     */
    const ATTRID = 126;

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @param \Magento\Framework\ObjectManagerInterface   $objectManager
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager
    ) {
        $this->_objectManager = $objectManager;
    }

    /**
     * product save before event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        //get product to be save
        $_product = $observer->getProduct();
        $url_key = $_product->getUrlKey();
        $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('catalog_product_entity_varchar');
        $sql = "Select * FROM " . $tableName ." Where value = '".$url_key."' AND attribute_id = ".self::ATTRID;
        $result = $connection->fetchAll($sql);
        if(!empty($result)){
            $url_key = $url_key.'-'.$_product->getSku();
            $_product->setUrlKey($url_key);
        }
    }
}
