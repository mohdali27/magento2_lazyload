<?php
/**
 * Webapp customization and fixes
 *
 * @category  Webapp
 * @package   Webapp_Marketplace
 * @author    Webapp
 */

namespace Webapp\Marketplace\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManager;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Webkul\Marketplace\Helper\Data as MarketplaceHelper;

/**
 * Override Webkul Marketplace SalesOrderPlaceAfterObserver Observer Model.
 */
class SalesOrderPlaceAfterObserver extends  \Webkul\Marketplace\Observer\SalesOrderPlaceAfterObserver
{
   
    /**
     * Order Place Operation method.
     *
     * @param \Magento\Sales\Model\Order $order
     * @param int                        $lastOrderId
     */
    public function orderPlacedOperations($order, $lastOrderId)
    {
        $this->productSalesCalculation($order);

        /*send placed order mail notification to seller*/

        $paymentCode = '';
        if ($order->getPayment()) {
            $paymentCode = $order->getPayment()->getMethod();
        }

        $shippingInfo = '';
        $shippingDes = '';

        $billingId = $order->getBillingAddress()->getId();

        $billaddress = $this->_objectManager->create(
            'Magento\Sales\Model\Order\Address'
        )->load($billingId);
        $billinginfo = $billaddress['firstname'].'<br/>'.
        $billaddress['street'].'<br/>'.
        $billaddress['city'].' '.
        $billaddress['region'].' '.
        $billaddress['postcode'].'<br/>'.
        $this->_objectManager->create(
            'Magento\Directory\Model\Country'
        )->load($billaddress['country_id'])->getName().'<br/>T:'.
        $billaddress['telephone'];

        $order->setOrderApprovalStatus(1)->save();

        $payment = $order->getPayment()->getMethodInstance()->getTitle();

        if ($order->getShippingAddress()) {
            $shippingId = $order->getShippingAddress()->getId();
            $address = $this->_objectManager->create(
                'Magento\Sales\Model\Order\Address'
            )->load($shippingId);
            $shippingInfo = $address['firstname'].'<br/>'.
            $address['street'].'<br/>'.
            $address['city'].' '.
            $address['region'].' '.
            $address['postcode'].'<br/>'.
            $this->_objectManager->create(
                'Magento\Directory\Model\Country'
            )->load($address['country_id'])->getName().'<br/>T:'.
            $address['telephone'];
            $shippingDes = $order->getShippingDescription();
        }

        $adminStoremail = $this->_marketplaceHelper->getAdminEmailId();
        $defaultTransEmailId = $this->_marketplaceHelper->getDefaultTransEmailId();
        $adminEmail = $adminStoremail ? $adminStoremail : $defaultTransEmailId;
        $adminUsername = 'Admin';

        $sellerOrder = $this->_objectManager->create(
            'Webkul\Marketplace\Model\Orders'
        )
        ->getCollection()
        ->addFieldToFilter('order_id', $lastOrderId)
        ->addFieldToFilter('seller_id', ['neq' => 0]);

        // Send email to seller only for split order
        if(count($sellerOrder->getData()) == 1) {
            foreach ($sellerOrder as $info) {
                $userdata = $this->_customerRepository->getById($info['seller_id']);
                $username = $userdata->getFirstname();
                $useremail = $userdata->getEmail();

                $senderInfo = [];
                $receiverInfo = [];

                $receiverInfo = [
                    'name' => $username,
                    'email' => $useremail,
                ];
                $senderInfo = [
                    'name' => $adminUsername,
                    'email' => $adminEmail,
                ];
                $totalprice = 0;
                $totalTaxAmount = 0;
                $codCharges = 0;
                $shippingCharges = 0;
                $orderinfo = '';

                $saleslistIds = [];
                $collection1 = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Saleslist'
                )->getCollection()
                ->addFieldToFilter('order_id', $lastOrderId)
                ->addFieldToFilter('seller_id', $info['seller_id'])
                ->addFieldToFilter('parent_item_id', ['null' => 'true'])
                ->addFieldToFilter('magerealorder_id', ['neq' => 0])
                ->addFieldToSelect('entity_id');

                $saleslistIds = $collection1->getData();

                $fetchsale = $this->_objectManager->create(
                    'Webkul\Marketplace\Model\Saleslist'
                )
                ->getCollection()
                ->addFieldToFilter(
                    'entity_id',
                    ['in' => $saleslistIds]
                );
                $fetchsale->getSellerOrderCollection();
                foreach ($fetchsale as $res) {
                    $product = $this->_productRepository->getById($res['mageproduct_id']);

                    /* product name */
                    $productName = $res->getMageproName();
                    $result = [];
                    $result = $this->getProductOptionData($res, $result);
                    $productName = $this->getProductNameHtml($result, $productName);
                    /* end */
                    if ($res->getProductType() == 'configurable') {
                        $configurableSalesItem = $this->_objectManager->create(
                            'Webkul\Marketplace\Model\Saleslist'
                        )->getCollection()
                        ->addFieldToFilter('order_id', $lastOrderId)
                        ->addFieldToFilter('seller_id', $info['seller_id'])
                        ->addFieldToFilter('parent_item_id', $res->getOrderItemId());
                        $configurableItemArr = $configurableSalesItem->getOrderedProductId();
                        $configurableItemId = $res['mageproduct_id'];
                        if (!empty($configurableItemArr)) {
                            $configurableItemId = $configurableItemArr[0];
                        }
                        $product = $this->_productRepository->getById($configurableItemId);
                    } else {
                        $product = $this->_productRepository->getById($res['mageproduct_id']);
                    }

                    $sku = $product->getSku();
                    $orderinfo = $orderinfo."<tbody><tr>
                                    <td class='item-info'>".$productName."</td>
                                    <td class='item-info'>".$sku."</td>
                                    <td class='item-qty'>".($res['magequantity'] * 1)."</td>
                                    <td class='item-price'>".
                                        $order->formatPrice(
                                            $res['magepro_price'] * $res['magequantity']
                                        ).
                                    '</td>
                                 </tr></tbody>';
                    $totalTaxAmount = $totalTaxAmount + $res['total_tax'];
                    $totalprice = $totalprice + ($res['magepro_price'] * $res['magequantity']);

                    /*
                    * Low Stock Notification mail to seller
                    */
                    if ($this->_marketplaceHelper->getlowStockNotification()) {
                        if (!empty($product['quantity_and_stock_status']['qty'])) {
                            $stockItemQty = $product['quantity_and_stock_status']['qty'];
                        } else {
                            $stockItemQty = $product->getQty();
                        }
                        if ($stockItemQty <= $this->_marketplaceHelper->getlowStockQty()) {
                            $orderProductInfo = "<tbody><tr>
                                    <td class='item-info'>".$productName."</td>
                                    <td class='item-info'>".$sku."</td>
                                    <td class='item-qty'>".($stockItemQty * 1).'</td>
                                 </tr></tbody>';

                            $emailTemplateVariables = [];
                            $emailTemplateVariables['myvar1'] = $orderProductInfo;
                            $emailTemplateVariables['myvar2'] = $username;

                            $this->_objectManager->get(
                                'Webkul\Marketplace\Helper\Email'
                            )->sendLowStockNotificationMail(
                                $emailTemplateVariables,
                                $senderInfo,
                                $receiverInfo
                            );
                        }
                    }
                }
                $shippingCharges = $info->getShippingCharges();
                $couponAmount = $info->getCouponAmount();
                $totalCod = 0;

                if ($paymentCode == 'mpcashondelivery') {
                    $totalCod = $info->getCodCharges();
                    $codRow = "<tr class='subtotal'>
                                <th colspan='3'>".__('Cash On Delivery Charges')."</th>
                                <td colspan='3'><span>".
                                    $order->formatPrice($totalCod).
                                '</span></td>
                                </tr>';
                } else {
                    $codRow = '';
                }

                $orderinfo = $orderinfo."<tfoot class='order-totals'>
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Shipping & Handling Charges')."</th>
                                        <td colspan='3'><span>".
                                        $order->formatPrice($shippingCharges)."</span></td>
                                    </tr>
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Discount')."</th>
                                        <td colspan='3'><span> -".
                                            $order->formatPrice($couponAmount).
                                        "</span></td>
                                    </tr>
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Tax Amount')."</th>
                                        <td colspan='3'><span>".
                                        $order->formatPrice($totalTaxAmount).'</span></td>
                                    </tr>'.$codRow."
                                    <tr class='subtotal'>
                                        <th colspan='3'>".__('Grandtotal')."</th>
                                        <td colspan='3'><span>".
                                        $order->formatPrice(
                                            $totalprice +
                                            $totalTaxAmount +
                                            $shippingCharges +
                                            $totalCod -
                                            $couponAmount
                                        ).'</span></td>
                                    </tr></tfoot>';

                $emailTemplateVariables = [];
                if ($shippingInfo != '') {
                    $isNotVirtual = 1;
                } else {
                    $isNotVirtual = 0;
                }
                $emailTempVariables['myvar1'] = $order->getRealOrderId();
                $emailTempVariables['myvar2'] = $order['created_at'];
                $emailTempVariables['myvar4'] = $billinginfo;
                $emailTempVariables['myvar5'] = $payment;
                $emailTempVariables['myvar6'] = $shippingInfo;
                $emailTempVariables['isNotVirtual'] = $isNotVirtual;
                $emailTempVariables['myvar9'] = $shippingDes;
                $emailTempVariables['myvar8'] = $orderinfo;
                $emailTempVariables['myvar3'] = $username;

                if ($this->_marketplaceHelper->getOrderApprovalRequired()) {
                    $emailTempVariables['seller_id'] = $info['seller_id'];
                    $emailTempVariables['order_id'] = $lastOrderId;
                    $emailTempVariables['sender_name'] = $senderInfo['name'];
                    $emailTempVariables['sender_email'] = $senderInfo['email'];
                    $emailTempVariables['receiver_name'] = $receiverInfo['name'];
                    $emailTempVariables['receiver_email'] = $receiverInfo['email'];

                    $orderPendingMailsCollection = $this->_objectManager->create(
                        'Webkul\Marketplace\Model\OrderPendingMails'
                    );
                    $orderPendingMailsCollection->setData($emailTempVariables);
                    $orderPendingMailsCollection->setCreatedAt($this->_date->gmtDate());
                    $orderPendingMailsCollection->setUpdatedAt($this->_date->gmtDate());
                    $orderPendingMailsCollection->save();
                    $order->setOrderApprovalStatus(0)->save();
                } else {
                    $this->_objectManager->get(
                        'Webkul\Marketplace\Helper\Email'
                    )->sendPlacedOrderEmail(
                        $emailTempVariables,
                        $senderInfo,
                        $receiverInfo
                    );
                }
            }
        }
    }

    
}
